package com.spring.javaProjectS12.vo;

import lombok.Data;

@Data
public class AdminFeaturesVO {
	private int idx;
	private String title;
	private String wdate;
	private String content;
	private String fname;
}
