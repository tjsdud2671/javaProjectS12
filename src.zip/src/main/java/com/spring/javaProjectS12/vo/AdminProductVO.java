package com.spring.javaProjectS12.vo;

import lombok.Data;

@Data
public class AdminProductVO {
	private int idx;
	private String name;
	private String color;
	private int price;
	private String fname;
	private String part;
	

}
