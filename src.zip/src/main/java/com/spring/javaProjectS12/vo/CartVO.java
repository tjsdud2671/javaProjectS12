package com.spring.javaProjectS12.vo;

import lombok.Data;

@Data
public class CartVO {
	private int idx;
	private	String userId;
	private	String userName;
	private	String productName;
	private	String productColor;
	private int amount;
	private	int productPrice;
	private String fname;
		
	}
