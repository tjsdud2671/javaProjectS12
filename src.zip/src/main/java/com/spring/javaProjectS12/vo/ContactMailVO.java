package com.spring.javaProjectS12.vo;

import lombok.Data;

@Data
public class ContactMailVO {
	public int idx;
	public String email;
	public String admin;
	public String content;
}
