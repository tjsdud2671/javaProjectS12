package com.spring.javaProjectS12.vo;

import lombok.Data;

@Data
public class InquiryVO {
	private int idx;
	private String name;
	private String email;
	private int onum;
	private String part;
	private String content;
}
